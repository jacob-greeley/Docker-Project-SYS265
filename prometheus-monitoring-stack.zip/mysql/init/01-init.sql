-- =============================================================================
-- MySQL Initialization Script
-- Creates the Prometheus exporter user and a sample application table
-- =============================================================================

-- Create the exporter user for mysqld_exporter with minimal privileges
CREATE USER IF NOT EXISTS 'exporter'@'%' IDENTIFIED BY 'exporterpass';
GRANT PROCESS, REPLICATION CLIENT, SELECT ON *.* TO 'exporter'@'%';
FLUSH PRIVILEGES;

-- Sample application schema
USE monitoring_db;

CREATE TABLE IF NOT EXISTS app_events (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    event_type  VARCHAR(50)  NOT NULL,
    message     TEXT,
    created_at  TIMESTAMP    DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO app_events (event_type, message) VALUES
    ('startup', 'Monitoring stack initialized'),
    ('info', 'MySQL database is ready for connections');
